/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
        ],
        symbols = {
            "stage": {
                version: "6.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "6.0.0.400",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'cruiseShip',
                            type: 'image',
                            rect: ['1px', '1px', '298px', '197px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"cruiseShip.png",'0px','0px']
                        },
                        {
                            id: 'aig_logo',
                            type: 'image',
                            rect: ['231px', '212px', '51px', '28px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"aig_logo.png",'0px','0px']
                        },
                        {
                            id: 'Quote_Button_Orange',
                            type: 'rect',
                            rect: ['9px', '212px', '137px', '28px', 'auto', 'auto'],
                            fill: ["rgba(226,110,30,1.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        },
                        {
                            id: 'Get_A_Quote',
                            type: 'text',
                            rect: ['19px', '217px', '143px', '33px', 'auto', 'auto'],
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-size: 13px;\">GET A QUOTE</span></p>",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "900", "none", "", "break-word", ""],
                            textStyle: ["1.5px", "", "", "", ""]
                        },
                        {
                            id: 'Large_transparent_rectangleCopy',
                            type: 'rect',
                            rect: ['1px', '1px', '298px', '197px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,89,132,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Small_transparent_rectangle',
                            type: 'rect',
                            rect: ['13px', '15px', '130px', '170px', 'auto', 'auto'],
                            opacity: '0.837398',
                            fill: ["rgba(0,89,132,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Discover_our_travel_insurance',
                            type: 'text',
                            rect: ['18px', '20px', '141px', '160px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px; line-height: 24px;\">​<span style=\"font-size: 16px; font-weight: 800; color: rgb(255, 255, 255);\">Discover</span></p><p style=\"margin: 0px; line-height: 24px;\"><span style=\"font-size: 16px; font-weight: 800; color: rgb(255, 255, 255);\">​our</span></p><p style=\"margin: 0px; line-height: 24px;\"><span style=\"font-size: 16px; font-weight: 800; color: rgb(255, 255, 255);\"></span><span style=\"font-size: 22px; font-weight: 800; color: rgb(253, 185, 19);\">travel</span></p><p style=\"margin: 0px; line-height: 24px;\"><span style=\"font-size: 22px; color: rgb(253, 185, 19); font-weight: 800;\">insurance</span></p><p style=\"margin: 0px; line-height: 24px;\"><span style=\"font-size: 22px; font-weight: 800; color: rgb(253, 185, 19);\"></span><span style=\"font-size: 17px; font-weight: 800; color: rgb(255, 255, 255);\">​</span><span style=\"font-size: 16px; font-weight: 800; color: rgb(255, 255, 255);\">products</span></p><p style=\"margin: 0px; line-height: 24px;\"><span style=\"font-size: 16px; font-weight: 800; color: rgb(255, 255, 255);\">​today.</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Planning_your_dream_cruise',
                            type: 'text',
                            rect: ['22px', '25px', '117px', '154px', 'auto', 'auto'],
                            opacity: '1',
                            text: "<p style=\"margin: 0px; line-height: 24px;\"></p><p style=\"margin: 0px; line-height: 24px;\"></p><p style=\"margin: 0px; font-family: Arial, Helvetica, sans-serif; font-weight: 800; font-style: normal; text-decoration: none; font-size: 17px; color: rgb(255, 255, 255); background-color: rgba(0, 0, 0, 0); letter-spacing: 0px; text-transform: none; word-spacing: 0px; text-align: left; text-indent: 0px; line-height: 27px;\"><span style=\"font-size: 23px;\">Planning</span></p><p style=\"margin: 0px; font-family: Arial, Helvetica, sans-serif; font-weight: 800; font-style: normal; text-decoration: none; font-size: 17px; color: rgb(255, 255, 255); background-color: rgba(0, 0, 0, 0); letter-spacing: 0px; text-transform: none; word-spacing: 0px; text-align: left; text-indent: 0px; line-height: 27px;\"><span style=\"font-size: 23px;\">​your</span></p><p style=\"margin: 0px; line-height: 27px;\"><span style=\"font-size: 23px; font-weight: 800; color: rgb(255, 255, 255);\">​</span><span style=\"font-size: 30px; font-weight: 800; color: rgb(253, 185, 19);\">dream</span></p><p style=\"margin: 0px; line-height: 27px;\"><span style=\"font-size: 30px; font-weight: 800; color: rgb(253, 185, 19);\">​cruise</span></p><p style=\"margin: 0px; line-height: 27px;\"><span style=\"font-size: 23px; font-weight: 800; color: rgb(255, 255, 255);\">​now?</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'peace_of_mind',
                            type: 'text',
                            rect: ['20px', '22px', '117px', '154px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin:0px\">​</p><p style=\"margin:0px\">​</p><p style=\"margin:0px\">​</p><p style=\"margin:0px\">​</p><p style=\"margin:0px\"><span style=\"font-size: 27px; color: rgb(253, 185, 19); font-weight: 800;\">PEACE</span><br></p><p style=\"margin: 0px; line-height: 27px;\"><span style=\"font-size: 27px; font-weight: 800; color: rgb(253, 185, 19);\">​OF</span></p><p style=\"margin: 0px; font-family: Arial, Helvetica, sans-serif; font-weight: 800; font-style: normal; text-decoration: none; font-size: 30px; color: rgb(253, 185, 19); background-color: rgba(0, 0, 0, 0); letter-spacing: 0px; text-transform: none; word-spacing: 0px; text-align: left; text-indent: 0px; line-height: 27px;\"><span style=\"font-size: 27px;\">MIND.</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Travel_with',
                            type: 'text',
                            rect: ['20px', '22px', '117px', '60px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin:0px\"><span style=\"font-size: 23px; color: rgb(255, 255, 255); font-weight: 800;\">Travel</span></p><p style=\"margin: 0px; font-family: Arial, Helvetica, sans-serif; font-weight: 800; font-style: normal; text-decoration: none; font-size: 17px; color: rgb(255, 255, 255); background-color: rgba(0, 0, 0, 0); letter-spacing: 0px; text-transform: none; word-spacing: 0px; text-align: left; text-indent: 0px; line-height: 27px;\"><span style=\"font-size: 23px;\">​with</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Available_coverage_includes',
                            type: 'text',
                            rect: ['22px', '25px', '260px', '27px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px; line-height: 22px;\"><span style=\"font-size: 14px; color: rgb(255, 255, 255); font-weight: 800;\">Available coverage includes:</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Emergency_Medical_Expenses',
                            type: 'text',
                            rect: ['53px', '50px', '234px', '27px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-size: 14px;\">Emergency Medical Expenses</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Trip_Cancellation',
                            type: 'text',
                            rect: ['53px', '75px', '234px', '27px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-size: 14px;\">Trip Cancellation and Interruption</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Lost_Luggage',
                            type: 'text',
                            rect: ['53px', '97px', '234px', '27px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-size: 14px;\">Lost or Stolen Luggage</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: '_24-7_Travel_Assistance',
                            type: 'text',
                            rect: ['53px', '120px', '234px', '27px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-size: 14px;\">24/7 Emergency Travel Assistance</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Concierge_Service',
                            type: 'text',
                            rect: ['53px', '143px', '234px', '27px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-size: 14px;\">Concierge Service</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'sunspot',
                            type: 'image',
                            rect: ['34px', '52px', '17px', '12px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"sunspot.png",'0px','0px']
                        },
                        {
                            id: 'sunspotCopy',
                            type: 'image',
                            rect: ['34px', '76px', '17px', '12px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"sunspot.png",'0px','0px']
                        },
                        {
                            id: 'sunspotCopy2',
                            type: 'image',
                            rect: ['34px', '99px', '17px', '12px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"sunspot.png",'0px','0px']
                        },
                        {
                            id: 'sunspotCopy3',
                            type: 'image',
                            rect: ['34px', '122px', '17px', '12px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"sunspot.png",'0px','0px']
                        },
                        {
                            id: 'sunspotCopy4',
                            type: 'image',
                            rect: ['34px', '145px', '17px', '12px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"sunspot.png",'0px','0px']
                        },
                        {
                            id: '__ANd_More',
                            type: 'text',
                            rect: ['23px', '162px', '260px', '27px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px; line-height: 22px;\"><span style=\"font-size: 14px; color: rgb(255, 255, 255); font-weight: 800;\">... and more!</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'viewfinder_white',
                            type: 'image',
                            rect: ['260px', '7px', '27px', '27px', 'auto', 'auto'],
                            opacity: '1',
                            fill: ["rgba(0,0,0,0)",im+"viewfinder_white.png",'0px','0px']
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '300px', '250px', 'auto', 'auto'],
                            sizeRange: ['0px','','',''],
                            overflow: 'hidden',
                            fill: ["rgba(0,164,228,1.00)"]
                        }
                    }
                },
                timeline: {
                    duration: 16000,
                    autoPlay: true,
                    data: [
                        [
                            "eid168",
                            "opacity",
                            0,
                            0,
                            "easeOutQuad",
                            "${Travel_with}",
                            '0',
                            '0'
                        ],
                        [
                            "eid169",
                            "opacity",
                            4000,
                            190,
                            "easeOutQuad",
                            "${Travel_with}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid170",
                            "opacity",
                            5000,
                            0,
                            "easeOutQuad",
                            "${Travel_with}",
                            '1',
                            '1'
                        ],
                        [
                            "eid171",
                            "opacity",
                            7000,
                            0,
                            "easeOutQuad",
                            "${Travel_with}",
                            '1',
                            '0'
                        ],
                        [
                            "eid107",
                            "width",
                            7000,
                            2000,
                            "easeOutQuad",
                            "${Discover_our_travel_insurance}",
                            '141px',
                            '130px'
                        ],
                        [
                            "eid154",
                            "left",
                            13000,
                            0,
                            "easeOutQuad",
                            "${_24-7_Travel_Assistance}",
                            '53px',
                            '53px'
                        ],
                        [
                            "eid155",
                            "left",
                            16000,
                            0,
                            "easeOutQuad",
                            "${_24-7_Travel_Assistance}",
                            '53px',
                            '53px'
                        ],
                        [
                            "eid20",
                            "left",
                            0,
                            10992,
                            "linear",
                            "${viewfinder_white}",
                            '125px',
                            '125px'
                        ],
                        [
                            "eid23",
                            "left",
                            11000,
                            0,
                            "linear",
                            "${viewfinder_white}",
                            '125px',
                            '260px'
                        ],
                        [
                            "eid41",
                            "opacity",
                            0,
                            0,
                            "easeOutQuad",
                            "${peace_of_mind}",
                            '0',
                            '0'
                        ],
                        [
                            "eid180",
                            "opacity",
                            4190,
                            0,
                            "easeOutQuad",
                            "${peace_of_mind}",
                            '0',
                            '0'
                        ],
                        [
                            "eid43",
                            "opacity",
                            4690,
                            810,
                            "easeOutQuad",
                            "${peace_of_mind}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid19",
                            "opacity",
                            7000,
                            0,
                            "easeOutQuad",
                            "${peace_of_mind}",
                            '1',
                            '0'
                        ],
                        [
                            "eid104",
                            "width",
                            0,
                            0,
                            "easeOutQuad",
                            "${Small_transparent_rectangle}",
                            '130px',
                            '130px'
                        ],
                        [
                            "eid12",
                            "opacity",
                            7000,
                            0,
                            "easeOutQuad",
                            "${Discover_our_travel_insurance}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid14",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${Discover_our_travel_insurance}",
                            '1',
                            '0'
                        ],
                        [
                            "eid163",
                            "left",
                            13000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy4}",
                            '34px',
                            '34px'
                        ],
                        [
                            "eid164",
                            "left",
                            16000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy4}",
                            '34px',
                            '34px'
                        ],
                        [
                            "eid60",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${Emergency_Medical_Expenses}",
                            '0',
                            '0'
                        ],
                        [
                            "eid76",
                            "opacity",
                            12500,
                            1000,
                            "easeOutQuad",
                            "${Emergency_Medical_Expenses}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid27",
                            "opacity",
                            11000,
                            1000,
                            "easeOutQuad",
                            "${Available_coverage_includes}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid73",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy4}",
                            '0',
                            '0'
                        ],
                        [
                            "eid74",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy4}",
                            '0',
                            '0'
                        ],
                        [
                            "eid94",
                            "opacity",
                            14500,
                            1000,
                            "easeOutQuad",
                            "${sunspotCopy4}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid63",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${_24-7_Travel_Assistance}",
                            '0',
                            '0'
                        ],
                        [
                            "eid89",
                            "opacity",
                            14000,
                            1000,
                            "easeOutQuad",
                            "${_24-7_Travel_Assistance}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid22",
                            "top",
                            0,
                            10992,
                            "linear",
                            "${viewfinder_white}",
                            '7px',
                            '7px'
                        ],
                        [
                            "eid25",
                            "top",
                            11000,
                            0,
                            "linear",
                            "${viewfinder_white}",
                            '7px',
                            '7px'
                        ],
                        [
                            "eid46",
                            "height",
                            12500,
                            0,
                            "easeOutQuad",
                            "${Available_coverage_includes}",
                            '27px',
                            '27px'
                        ],
                        [
                            "eid156",
                            "left",
                            13000,
                            0,
                            "easeOutQuad",
                            "${Lost_Luggage}",
                            '53px',
                            '53px'
                        ],
                        [
                            "eid157",
                            "left",
                            16000,
                            0,
                            "easeOutQuad",
                            "${Lost_Luggage}",
                            '53px',
                            '53px'
                        ],
                        [
                            "eid110",
                            "left",
                            4690,
                            0,
                            "easeOutQuad",
                            "${peace_of_mind}",
                            '20px',
                            '20px'
                        ],
                        [
                            "eid165",
                            "left",
                            3000,
                            0,
                            "easeOutQuad",
                            "${Emergency_Medical_Expenses}",
                            '53px',
                            '53px'
                        ],
                        [
                            "eid166",
                            "left",
                            13000,
                            0,
                            "easeOutQuad",
                            "${Emergency_Medical_Expenses}",
                            '53px',
                            '53px'
                        ],
                        [
                            "eid161",
                            "left",
                            16000,
                            0,
                            "easeOutQuad",
                            "${Emergency_Medical_Expenses}",
                            '53px',
                            '53px'
                        ],
                        [
                            "eid106",
                            "height",
                            7000,
                            0,
                            "easeOutQuad",
                            "${Discover_our_travel_insurance}",
                            '160px',
                            '160px'
                        ],
                        [
                            "eid67",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy}",
                            '0',
                            '0'
                        ],
                        [
                            "eid68",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy}",
                            '0',
                            '0'
                        ],
                        [
                            "eid102",
                            "opacity",
                            13000,
                            1000,
                            "easeOutQuad",
                            "${sunspotCopy}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid172",
                            "left",
                            4190,
                            0,
                            "easeOutQuad",
                            "${Travel_with}",
                            '20px',
                            '20px'
                        ],
                        [
                            "eid152",
                            "left",
                            13000,
                            0,
                            "easeOutQuad",
                            "${Concierge_Service}",
                            '53px',
                            '53px'
                        ],
                        [
                            "eid153",
                            "left",
                            16000,
                            0,
                            "easeOutQuad",
                            "${Concierge_Service}",
                            '53px',
                            '53px'
                        ],
                        [
                            "eid150",
                            "left",
                            13000,
                            0,
                            "easeOutQuad",
                            "${sunspot}",
                            '34px',
                            '34px'
                        ],
                        [
                            "eid151",
                            "left",
                            16000,
                            0,
                            "easeOutQuad",
                            "${sunspot}",
                            '34px',
                            '34px'
                        ],
                        [
                            "eid167",
                            "top",
                            4190,
                            0,
                            "easeOutQuad",
                            "${Travel_with}",
                            '22px',
                            '22px'
                        ],
                        [
                            "eid61",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${Trip_Cancellation}",
                            '0',
                            '0'
                        ],
                        [
                            "eid101",
                            "opacity",
                            13000,
                            1000,
                            "easeOutQuad",
                            "${Trip_Cancellation}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid108",
                            "top",
                            7000,
                            0,
                            "easeOutQuad",
                            "${Discover_our_travel_insurance}",
                            '20px',
                            '20px'
                        ],
                        [
                            "eid33",
                            "opacity",
                            0,
                            0,
                            "easeOutQuad",
                            "${Small_transparent_rectangle}",
                            '0.837398',
                            '0.837398'
                        ],
                        [
                            "eid21",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${Small_transparent_rectangle}",
                            '0.837398',
                            '0'
                        ],
                        [
                            "eid62",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${Lost_Luggage}",
                            '0',
                            '0'
                        ],
                        [
                            "eid85",
                            "opacity",
                            13500,
                            1000,
                            "easeOutQuad",
                            "${Lost_Luggage}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid148",
                            "left",
                            13000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy}",
                            '34px',
                            '34px'
                        ],
                        [
                            "eid149",
                            "left",
                            16000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy}",
                            '34px',
                            '34px'
                        ],
                        [
                            "eid32",
                            "opacity",
                            0,
                            0,
                            "easeOutQuad",
                            "${Planning_your_dream_cruise}",
                            '1',
                            '1'
                        ],
                        [
                            "eid9",
                            "opacity",
                            3000,
                            0,
                            "easeOutQuad",
                            "${Planning_your_dream_cruise}",
                            '1',
                            '1'
                        ],
                        [
                            "eid35",
                            "opacity",
                            3560,
                            440,
                            "easeOutQuad",
                            "${Planning_your_dream_cruise}",
                            '1',
                            '0'
                        ],
                        [
                            "eid146",
                            "left",
                            13000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy2}",
                            '34px',
                            '34px'
                        ],
                        [
                            "eid147",
                            "left",
                            16000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy2}",
                            '34px',
                            '34px'
                        ],
                        [
                            "eid173",
                            "height",
                            5500,
                            0,
                            "easeOutQuad",
                            "${Travel_with}",
                            '60px',
                            '60px'
                        ],
                        [
                            "eid158",
                            "left",
                            13000,
                            0,
                            "easeOutQuad",
                            "${Trip_Cancellation}",
                            '53px',
                            '53px'
                        ],
                        [
                            "eid159",
                            "left",
                            16000,
                            0,
                            "easeOutQuad",
                            "${Trip_Cancellation}",
                            '53px',
                            '53px'
                        ],
                        [
                            "eid111",
                            "top",
                            4690,
                            0,
                            "easeOutQuad",
                            "${peace_of_mind}",
                            '22px',
                            '22px'
                        ],
                        [
                            "eid24",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${Large_transparent_rectangleCopy}",
                            '0.000000',
                            '0.84'
                        ],
                        [
                            "eid69",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${sunspot}",
                            '0',
                            '0'
                        ],
                        [
                            "eid98",
                            "opacity",
                            12500,
                            1000,
                            "easeOutQuad",
                            "${sunspot}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid109",
                            "left",
                            7000,
                            0,
                            "easeOutQuad",
                            "${Discover_our_travel_insurance}",
                            '18px',
                            '18px'
                        ],
                        [
                            "eid71",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy3}",
                            '0',
                            '0'
                        ],
                        [
                            "eid72",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy3}",
                            '0',
                            '0'
                        ],
                        [
                            "eid90",
                            "opacity",
                            14000,
                            1000,
                            "easeOutQuad",
                            "${sunspotCopy3}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid96",
                            "opacity",
                            15000,
                            1000,
                            "easeOutQuad",
                            "${__ANd_More}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid65",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy2}",
                            '0',
                            '0'
                        ],
                        [
                            "eid66",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy2}",
                            '0',
                            '0'
                        ],
                        [
                            "eid86",
                            "opacity",
                            13500,
                            1000,
                            "easeOutQuad",
                            "${sunspotCopy2}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid124",
                            "left",
                            13000,
                            0,
                            "easeOutQuad",
                            "${__ANd_More}",
                            '23px',
                            '23px'
                        ],
                        [
                            "eid64",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${Concierge_Service}",
                            '0',
                            '0'
                        ],
                        [
                            "eid93",
                            "opacity",
                            14500,
                            1000,
                            "easeOutQuad",
                            "${Concierge_Service}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid144",
                            "left",
                            13000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy3}",
                            '34px',
                            '34px'
                        ],
                        [
                            "eid145",
                            "left",
                            16000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy3}",
                            '34px',
                            '34px'
                        ]
                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("CA-Cruise-300x250_edgeActions.js");
})("EDGE-175415339");
