/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
        ],
        symbols = {
            "stage": {
                version: "6.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "6.0.0.400",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'background',
                            type: 'image',
                            rect: ['1px', '1px', '500px', '88px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"background.jpg",'0px','0px']
                        },
                        {
                            id: 'Large_transparent_rectangle',
                            type: 'rect',
                            rect: ['1px', '0px', '500px', '89px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,89,132,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'aig_logo',
                            type: 'image',
                            rect: ['601px', '12px', '51px', '28px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"aig_logo.png",'0px','0px']
                        },
                        {
                            id: 'Small_transparent_rectangle',
                            type: 'rect',
                            rect: ['1px', '1px', '250px', '89px', 'auto', 'auto'],
                            opacity: '0.837398',
                            fill: ["rgba(0,89,132,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Quote_Button_Orange',
                            type: 'rect',
                            rect: ['568px', '52px', '117px', '28px', 'auto', 'auto'],
                            fill: ["rgba(226,110,30,1.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        },
                        {
                            id: 'Get_A_Quote',
                            type: 'text',
                            rect: ['572px', '57px', '143px', '33px', 'auto', 'auto'],
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255);\">GET A QUOTE</span></p>",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "900", "none", "", "break-word", ""],
                            textStyle: ["1.5px", "", "", "", ""]
                        },
                        {
                            id: 'Discover_our_travel_insurance',
                            type: 'text',
                            rect: ['10px', '6px', '311px', '160px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px; line-height: 21px;\">​<span style=\"font-size: 23px; font-weight: 800; color: rgb(255, 255, 255);\">Discover&nbsp;​our</span></p><p style=\"margin: 0px; line-height: 21px;\"><span style=\"font-size: 26px; font-weight: 800; color: rgb(253, 185, 19);\">trave</span><span style=\"font-size: 26px; font-weight: 800; color: rgb(255, 185, 16);\">l&nbsp;insurance</span></p><p style=\"margin: 0px; line-height: 21px;\"><span style=\"font-size: 26px; font-weight: 800; color: rgb(255, 255, 255);\">​</span><span style=\"font-size: 23px; font-weight: 800; color: rgb(255, 255, 255);\">products&nbsp;​today.</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Planning_your_dream_cruise',
                            type: 'text',
                            rect: ['14px', '-19px', '233px', '154px', 'auto', 'auto'],
                            opacity: '1',
                            text: "<p style=\"margin: 0px; line-height: 24px;\"><br></p><p style=\"margin: 0px; font-family: Arial, Helvetica, sans-serif; font-weight: 800; font-style: normal; text-decoration: none; font-size: 17px; color: rgb(255, 255, 255); background-color: rgba(0, 0, 0, 0); letter-spacing: 0px; text-transform: none; word-spacing: 0px; text-align: left; text-indent: 0px; line-height: 24px;\"><span style=\"font-size: 23px;\">Planning&nbsp;</span><span style=\"font-size: 23px;\">​your</span></p><p style=\"margin: 0px; line-height: 24px;\"><span style=\"font-size: 23px; font-weight: 800; color: rgb(255, 255, 255);\">​</span><span style=\"font-size: 30px; font-weight: 800; color: rgb(253, 185, 19);\">dream&nbsp;</span><span style=\"font-size: 30px; font-weight: 800; color: rgb(253, 185, 19);\">​cruise</span></p><p style=\"margin: 0px; line-height: 24px;\"><span style=\"font-size: 23px; font-weight: 800; color: rgb(255, 255, 255);\">​now?</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'peace_of_mind',
                            type: 'text',
                            rect: ['18px', '-34px', '217px', '154px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin:0px\">​</p><p style=\"margin:0px\">​</p><p style=\"margin:0px\">​</p><p style=\"margin:0px\">​</p><p style=\"margin:0px\"><span style=\"font-size: 27px; color: rgb(253, 185, 19); font-weight: 800;\">PEACE</span><br></p><p style=\"margin: 0px; line-height: 27px;\"><span style=\"font-size: 27px; font-weight: 800; color: rgb(253, 185, 19);\">​</span><span style=\"font-size: 27px; font-weight: 800; color: rgb(255, 187, 21);\">OF&nbsp;MIND.</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Travel_with',
                            type: 'text',
                            rect: ['14px', '-2px', '169px', '60px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin:0px\"><span style=\"font-size: 23px; color: rgb(255, 255, 255); font-weight: 800;\">Travel&nbsp;​with</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'sunspot',
                            type: 'image',
                            rect: ['273px', '29px', '17px', '12px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"sunspot.png",'0px','0px']
                        },
                        {
                            id: 'sunspotCopy',
                            type: 'image',
                            rect: ['20px', '49px', '17px', '12px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"sunspot.png",'0px','0px']
                        },
                        {
                            id: 'sunspotCopy2',
                            type: 'image',
                            rect: ['20px', '69px', '17px', '12px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"sunspot.png",'0px','0px']
                        },
                        {
                            id: 'sunspotCopy3',
                            type: 'image',
                            rect: ['20px', '30px', '17px', '12px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"sunspot.png",'0px','0px']
                        },
                        {
                            id: 'sunspotCopy4',
                            type: 'image',
                            rect: ['273px', '50px', '17px', '12px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"sunspot.png",'0px','0px']
                        },
                        {
                            id: '__ANd_More',
                            type: 'text',
                            rect: ['277px', '65px', '107px', '27px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px; line-height: 22px;\"><span style=\"font-size: 14px; color: rgb(255, 255, 255); font-weight: 800;\">... and more!</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: '_24-7_Travel_Assistance',
                            type: 'text',
                            rect: ['37px', '29px', '241px', '33px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-size: 14px;\">24/7 Emergency Travel Assistance</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Available_coverage_includes',
                            type: 'text',
                            rect: ['16px', '6px', '254px', '27px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px; line-height: 22px;\"><span style=\"font-size: 14px; color: rgb(255, 255, 255); font-weight: 800;\">Available coverage includes:</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Trip_Cancellation',
                            type: 'text',
                            rect: ['37px', '49px', '233px', '27px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-size: 14px;\">Trip Cancellation and Interruption</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Lost_Luggage',
                            type: 'text',
                            rect: ['37px', '69px', '169px', '27px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-size: 14px;\">Lost or Stolen Luggage</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Emergency_Medical_Expenses',
                            type: 'text',
                            rect: ['290px', '28px', '210px', '28px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-size: 14px;\">Emergency Medical Expenses</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'Concierge_Service',
                            type: 'text',
                            rect: ['292px', '49px', '138px', '23px', 'auto', 'auto'],
                            opacity: '0',
                            text: "<p style=\"margin: 0px;\">​<span style=\"color: rgb(255, 255, 255); font-size: 14px;\">Concierge Service</span></p>",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [12, "px"], "rgba(0,0,0,1)", "400", "none", "normal", "break-word", "normal"],
                            textStyle: ["", "", "", "", "none"]
                        },
                        {
                            id: 'viewfinder_white',
                            type: 'image',
                            rect: ['223px', '6px', '23px', '23px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"viewfinder_white.png",'0px','0px']
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '728px', '90px', 'auto', 'auto'],
                            sizeRange: ['0px','','',''],
                            overflow: 'hidden',
                            fill: ["rgba(0,164,228,1.00)"]
                        }
                    }
                },
                timeline: {
                    duration: 16508,
                    autoPlay: true,
                    data: [
                        [
                            "eid168",
                            "opacity",
                            0,
                            0,
                            "easeOutQuad",
                            "${Travel_with}",
                            '0',
                            '0'
                        ],
                        [
                            "eid169",
                            "opacity",
                            4000,
                            190,
                            "easeOutQuad",
                            "${Travel_with}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid170",
                            "opacity",
                            5000,
                            0,
                            "easeOutQuad",
                            "${Travel_with}",
                            '1',
                            '1'
                        ],
                        [
                            "eid171",
                            "opacity",
                            7000,
                            0,
                            "easeOutQuad",
                            "${Travel_with}",
                            '1',
                            '0'
                        ],
                        [
                            "eid3",
                            "left",
                            10993,
                            7,
                            "linear",
                            "${viewfinder_white}",
                            '223px',
                            '472px'
                        ],
                        [
                            "eid56",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${sunspotCopy3}",
                            '0',
                            '0'
                        ],
                        [
                            "eid71",
                            "opacity",
                            9492,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy3}",
                            '0',
                            '0'
                        ],
                        [
                            "eid72",
                            "opacity",
                            10492,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy3}",
                            '0',
                            '0'
                        ],
                        [
                            "eid90",
                            "opacity",
                            12492,
                            1000,
                            "easeOutQuad",
                            "${sunspotCopy3}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid49",
                            "opacity",
                            13492,
                            3016,
                            "linear",
                            "${sunspotCopy3}",
                            '1',
                            '0.87999999523163'
                        ],
                        [
                            "eid12",
                            "opacity",
                            7000,
                            0,
                            "easeOutQuad",
                            "${Discover_our_travel_insurance}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid14",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${Discover_our_travel_insurance}",
                            '1',
                            '0'
                        ],
                        [
                            "eid60",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${Emergency_Medical_Expenses}",
                            '0',
                            '0'
                        ],
                        [
                            "eid76",
                            "opacity",
                            14000,
                            1000,
                            "easeOutQuad",
                            "${Emergency_Medical_Expenses}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid27",
                            "opacity",
                            11000,
                            1000,
                            "easeOutQuad",
                            "${Available_coverage_includes}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid57",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${sunspotCopy4}",
                            '0',
                            '0'
                        ],
                        [
                            "eid73",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy4}",
                            '0',
                            '0'
                        ],
                        [
                            "eid74",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy4}",
                            '0',
                            '0'
                        ],
                        [
                            "eid94",
                            "opacity",
                            14500,
                            1000,
                            "easeOutQuad",
                            "${sunspotCopy4}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid2",
                            "top",
                            10993,
                            0,
                            "linear",
                            "${viewfinder_white}",
                            '6px',
                            '6px'
                        ],
                        [
                            "eid63",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${_24-7_Travel_Assistance}",
                            '0',
                            '0'
                        ],
                        [
                            "eid89",
                            "opacity",
                            12500,
                            1000,
                            "easeOutQuad",
                            "${_24-7_Travel_Assistance}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid55",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${sunspotCopy2}",
                            '0',
                            '0'
                        ],
                        [
                            "eid65",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy2}",
                            '0',
                            '0'
                        ],
                        [
                            "eid66",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy2}",
                            '0',
                            '0'
                        ],
                        [
                            "eid86",
                            "opacity",
                            13500,
                            1000,
                            "easeOutQuad",
                            "${sunspotCopy2}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid54",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${sunspotCopy}",
                            '0',
                            '0'
                        ],
                        [
                            "eid67",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy}",
                            '0',
                            '0'
                        ],
                        [
                            "eid68",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${sunspotCopy}",
                            '0',
                            '0'
                        ],
                        [
                            "eid102",
                            "opacity",
                            13000,
                            1000,
                            "easeOutQuad",
                            "${sunspotCopy}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid337",
                            "opacity",
                            10786,
                            296,
                            "easeOutQuad",
                            "${Large_transparent_rectangle}",
                            '0',
                            '0.84'
                        ],
                        [
                            "eid33",
                            "opacity",
                            0,
                            0,
                            "easeOutQuad",
                            "${Small_transparent_rectangle}",
                            '0.837398',
                            '0.837398'
                        ],
                        [
                            "eid21",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${Small_transparent_rectangle}",
                            '0.837398',
                            '0'
                        ],
                        [
                            "eid62",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${Lost_Luggage}",
                            '0',
                            '0'
                        ],
                        [
                            "eid85",
                            "opacity",
                            13500,
                            1000,
                            "easeOutQuad",
                            "${Lost_Luggage}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid32",
                            "opacity",
                            0,
                            0,
                            "easeOutQuad",
                            "${Planning_your_dream_cruise}",
                            '1',
                            '1'
                        ],
                        [
                            "eid9",
                            "opacity",
                            3000,
                            0,
                            "easeOutQuad",
                            "${Planning_your_dream_cruise}",
                            '1',
                            '1'
                        ],
                        [
                            "eid35",
                            "opacity",
                            3560,
                            440,
                            "easeOutQuad",
                            "${Planning_your_dream_cruise}",
                            '1',
                            '0'
                        ],
                        [
                            "eid53",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${sunspot}",
                            '0',
                            '0'
                        ],
                        [
                            "eid69",
                            "opacity",
                            11000,
                            0,
                            "easeOutQuad",
                            "${sunspot}",
                            '0',
                            '0'
                        ],
                        [
                            "eid98",
                            "opacity",
                            14000,
                            1000,
                            "easeOutQuad",
                            "${sunspot}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid96",
                            "opacity",
                            15000,
                            1000,
                            "easeOutQuad",
                            "${__ANd_More}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid41",
                            "opacity",
                            0,
                            0,
                            "easeOutQuad",
                            "${peace_of_mind}",
                            '0',
                            '0'
                        ],
                        [
                            "eid180",
                            "opacity",
                            4190,
                            0,
                            "easeOutQuad",
                            "${peace_of_mind}",
                            '0',
                            '0'
                        ],
                        [
                            "eid43",
                            "opacity",
                            4690,
                            810,
                            "easeOutQuad",
                            "${peace_of_mind}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid19",
                            "opacity",
                            7000,
                            0,
                            "easeOutQuad",
                            "${peace_of_mind}",
                            '1',
                            '0'
                        ],
                        [
                            "eid61",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${Trip_Cancellation}",
                            '0',
                            '0'
                        ],
                        [
                            "eid101",
                            "opacity",
                            13000,
                            1000,
                            "easeOutQuad",
                            "${Trip_Cancellation}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid64",
                            "opacity",
                            12000,
                            0,
                            "easeOutQuad",
                            "${Concierge_Service}",
                            '0',
                            '0'
                        ],
                        [
                            "eid93",
                            "opacity",
                            14500,
                            1000,
                            "easeOutQuad",
                            "${Concierge_Service}",
                            '0.000000',
                            '1'
                        ]
                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("CA-Cruise-728x90_edgeActions.js");
})("EDGE-175415339");
