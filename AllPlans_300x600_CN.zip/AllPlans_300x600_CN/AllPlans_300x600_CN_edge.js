/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
            "https://s1.adform.net/banners/scripts/rmb/Adform.DHTML.js"
        ],
        symbols = {
            "stage": {
                version: "6.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "6.0.0.400",
                scaleToFit: "both",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'CallNow',
                            symbolName: 'CallNow',
                            type: 'rect',
                            rect: ['89', '494', '122', '32', 'auto', 'auto']
                        },
                        {
                            id: 'Insure2',
                            symbolName: 'Insure',
                            type: 'rect',
                            rect: ['108px', '158px', '83', '17', 'auto', 'auto'],
                            opacity: '0'
                        },
                        {
                            id: 'vacation',
                            display: 'none',
                            type: 'image',
                            rect: ['37px', '171px', '229px', '32px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",'vacation.svg','0px','0px']
                        },
                        {
                            id: 'ofyour',
                            display: 'none',
                            type: 'image',
                            rect: ['113px', '-57px', '73px', '25px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",'ofyour.svg','0px','0px']
                        },
                        {
                            id: 'dreams',
                            display: 'none',
                            type: 'image',
                            rect: ['37px', '258px', '230px', '38px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",'dreams.svg','0px','0px']
                        },
                        {
                            id: 'choose',
                            type: 'image',
                            rect: ['37px', '70px', '229px', '104px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",'choose.svg','0px','0px']
                        },
                        {
                            id: 'silver3',
                            type: 'image',
                            rect: ['57px', '301px', '191px', '18px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",'silver3.svg','0px','0px']
                        },
                        {
                            id: 'gold2',
                            type: 'image',
                            rect: ['61px', '332px', '183px', '18px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",'gold2.svg','0px','0px']
                        },
                        {
                            id: 'platinum2',
                            type: 'image',
                            rect: ['34px', '395px', '236px', '18px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",'platinum2.svg','0px','0px']
                        },
                        {
                            id: 'TG2',
                            type: 'image',
                            rect: ['10px', '18px', '283px', '38px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",'TG2.svg','0px','0px']
                        },
                        {
                            id: 'TravelInsur',
                            type: 'image',
                            rect: ['16px', '223px', '270px', '104px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",'TravelInsur.svg','0px','0px']
                        },
                        {
                            id: 'aig2',
                            type: 'image',
                            rect: ['113px', '536px', '73px', '39px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",'aig2.svg','0px','0px']
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '300px', '600px', 'auto', 'auto'],
                            overflow: 'hidden',
                            fill: ["rgba(0,89,132,1.00)",[270,[['rgba(0,89,132,1.00)',100],['rgba(255,255,255,0.00)',100]]]]
                        }
                    }
                },
                timeline: {
                    duration: 5821,
                    autoPlay: true,
                    data: [
                        [
                            "eid29",
                            "display",
                            0,
                            0,
                            "linear",
                            "${vacation}",
                            'none',
                            'none'
                        ],
                        [
                            "eid30",
                            "display",
                            500,
                            0,
                            "linear",
                            "${vacation}",
                            'none',
                            'block'
                        ],
                        [
                            "eid309",
                            "width",
                            500,
                            0,
                            "linear",
                            "${vacation}",
                            '229px',
                            '229px'
                        ],
                        [
                            "eid64",
                            "opacity",
                            1495,
                            510,
                            "linear",
                            "${dreams}",
                            '0',
                            '1'
                        ],
                        [
                            "eid93",
                            "opacity",
                            3000,
                            500,
                            "linear",
                            "${dreams}",
                            '1',
                            '0'
                        ],
                        [
                            "eid389",
                            "top",
                            3793,
                            102,
                            "linear",
                            "${platinum2}",
                            '395px',
                            '367px'
                        ],
                        [
                            "eid409",
                            "top",
                            5000,
                            101,
                            "linear",
                            "${platinum2}",
                            '367px',
                            '215px'
                        ],
                        [
                            "eid374",
                            "top",
                            3609,
                            86,
                            "linear",
                            "${silver3}",
                            '301px',
                            '217px'
                        ],
                        [
                            "eid407",
                            "top",
                            5000,
                            101,
                            "linear",
                            "${silver3}",
                            '217px',
                            '41px'
                        ],
                        [
                            "eid14",
                            "top",
                            0,
                            500,
                            "linear",
                            "${Insure2}",
                            '158px',
                            '71px'
                        ],
                        [
                            "eid83",
                            "top",
                            3000,
                            500,
                            "linear",
                            "${Insure2}",
                            '71px',
                            '-127px'
                        ],
                        [
                            "eid10",
                            "left",
                            0,
                            0,
                            "linear",
                            "${Insure2}",
                            '108px',
                            '108px'
                        ],
                        [
                            "eid12",
                            "left",
                            500,
                            0,
                            "linear",
                            "${Insure2}",
                            '108px',
                            '108px'
                        ],
                        [
                            "eid71",
                            "left",
                            3000,
                            0,
                            "linear",
                            "${Insure2}",
                            '108px',
                            '108px'
                        ],
                        [
                            "eid75",
                            "left",
                            3500,
                            0,
                            "linear",
                            "${Insure2}",
                            '108px',
                            '108px'
                        ],
                        [
                            "eid1",
                            "height",
                            0,
                            0,
                            "linear",
                            "${Stage}",
                            '600px',
                            '600px'
                        ],
                        [
                            "eid41",
                            "display",
                            0,
                            0,
                            "linear",
                            "${ofyour}",
                            'none',
                            'none'
                        ],
                        [
                            "eid40",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${ofyour}",
                            'none',
                            'block'
                        ],
                        [
                            "eid369",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${silver3}",
                            '0',
                            '0'
                        ],
                        [
                            "eid372",
                            "opacity",
                            3609,
                            86,
                            "linear",
                            "${silver3}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid412",
                            "opacity",
                            5000,
                            101,
                            "linear",
                            "${silver3}",
                            '1',
                            '0'
                        ],
                        [
                            "eid421",
                            "top",
                            5101,
                            96,
                            "linear",
                            "${TG2}",
                            '18px',
                            '93px'
                        ],
                        [
                            "eid52",
                            "top",
                            1000,
                            495,
                            "linear",
                            "${ofyour}",
                            '228px',
                            '137px'
                        ],
                        [
                            "eid86",
                            "top",
                            3000,
                            500,
                            "linear",
                            "${ofyour}",
                            '137px',
                            '-57px'
                        ],
                        [
                            "eid428",
                            "top",
                            5197,
                            105,
                            "linear",
                            "${TravelInsur}",
                            '223px',
                            '157px'
                        ],
                        [
                            "eid381",
                            "top",
                            3695,
                            98,
                            "linear",
                            "${gold2}",
                            '332px',
                            '290px'
                        ],
                        [
                            "eid408",
                            "top",
                            5000,
                            101,
                            "linear",
                            "${gold2}",
                            '290px',
                            '127px'
                        ],
                        [
                            "eid361",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${choose}",
                            '0',
                            '0'
                        ],
                        [
                            "eid364",
                            "opacity",
                            3500,
                            109,
                            "linear",
                            "${choose}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid413",
                            "opacity",
                            5000,
                            101,
                            "linear",
                            "${choose}",
                            '1',
                            '0'
                        ],
                        [
                            "eid367",
                            "top",
                            3500,
                            109,
                            "linear",
                            "${choose}",
                            '-53px',
                            '70px'
                        ],
                        [
                            "eid406",
                            "top",
                            5000,
                            101,
                            "linear",
                            "${choose}",
                            '70px',
                            '-117px'
                        ],
                        [
                            "eid43",
                            "left",
                            1000,
                            0,
                            "linear",
                            "${ofyour}",
                            '113px',
                            '113px'
                        ],
                        [
                            "eid44",
                            "left",
                            1495,
                            0,
                            "linear",
                            "${ofyour}",
                            '113px',
                            '113px'
                        ],
                        [
                            "eid67",
                            "left",
                            3000,
                            0,
                            "linear",
                            "${ofyour}",
                            '113px',
                            '113px'
                        ],
                        [
                            "eid79",
                            "left",
                            3500,
                            0,
                            "linear",
                            "${ofyour}",
                            '113px',
                            '113px'
                        ],
                        [
                            "eid39",
                            "opacity",
                            500,
                            500,
                            "linear",
                            "${vacation}",
                            '0',
                            '1'
                        ],
                        [
                            "eid97",
                            "opacity",
                            3000,
                            500,
                            "linear",
                            "${vacation}",
                            '1',
                            '0'
                        ],
                        [
                            "eid18",
                            "opacity",
                            0,
                            500,
                            "linear",
                            "${Insure2}",
                            '0',
                            '1'
                        ],
                        [
                            "eid99",
                            "opacity",
                            3000,
                            500,
                            "linear",
                            "${Insure2}",
                            '1',
                            '0'
                        ],
                        [
                            "eid37",
                            "top",
                            500,
                            500,
                            "linear",
                            "${vacation}",
                            '171px',
                            '99px'
                        ],
                        [
                            "eid85",
                            "top",
                            3000,
                            500,
                            "linear",
                            "${vacation}",
                            '99px',
                            '-100px'
                        ],
                        [
                            "eid59",
                            "top",
                            1495,
                            510,
                            "linear",
                            "${dreams}",
                            '258px',
                            '170px'
                        ],
                        [
                            "eid87",
                            "top",
                            3000,
                            500,
                            "linear",
                            "${dreams}",
                            '170px',
                            '-38px'
                        ],
                        [
                            "eid313",
                            "height",
                            1495,
                            0,
                            "linear",
                            "${dreams}",
                            '38px',
                            '38px'
                        ],
                        [
                            "eid314",
                            "width",
                            1495,
                            0,
                            "linear",
                            "${dreams}",
                            '230px',
                            '230px'
                        ],
                        [
                            "eid308",
                            "height",
                            500,
                            0,
                            "linear",
                            "${vacation}",
                            '32px',
                            '32px'
                        ],
                        [
                            "eid4",
                            "background-image",
                            0,
                            0,
                            "linear",
                            "${Stage}",
                            [270,[['rgba(0,89,132,1.00)',100],['rgba(255,255,255,0.00)',100]]],
                            [270,[['rgba(0,89,132,1.00)',100],['rgba(255,255,255,0.00)',100]]]
                        ],
                        [
                            "eid51",
                            "opacity",
                            1000,
                            495,
                            "linear",
                            "${ofyour}",
                            '0',
                            '1'
                        ],
                        [
                            "eid95",
                            "opacity",
                            3000,
                            500,
                            "linear",
                            "${ofyour}",
                            '1',
                            '0'
                        ],
                        [
                            "eid310",
                            "left",
                            500,
                            250,
                            "linear",
                            "${vacation}",
                            '35px',
                            '34px'
                        ],
                        [
                            "eid311",
                            "left",
                            750,
                            118,
                            "linear",
                            "${vacation}",
                            '34px',
                            '33px'
                        ],
                        [
                            "eid312",
                            "left",
                            868,
                            132,
                            "linear",
                            "${vacation}",
                            '33px',
                            '37px'
                        ],
                        [
                            "eid321",
                            "left",
                            3000,
                            0,
                            "linear",
                            "${vacation}",
                            '37px',
                            '37px'
                        ],
                        [
                            "eid322",
                            "left",
                            3500,
                            0,
                            "linear",
                            "${vacation}",
                            '37px',
                            '37px'
                        ],
                        [
                            "eid53",
                            "display",
                            0,
                            0,
                            "linear",
                            "${dreams}",
                            'none',
                            'none'
                        ],
                        [
                            "eid54",
                            "display",
                            1495,
                            0,
                            "linear",
                            "${dreams}",
                            'none',
                            'block'
                        ],
                        [
                            "eid376",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${gold2}",
                            '0',
                            '0'
                        ],
                        [
                            "eid379",
                            "opacity",
                            3695,
                            98,
                            "linear",
                            "${gold2}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid411",
                            "opacity",
                            5000,
                            101,
                            "linear",
                            "${gold2}",
                            '1',
                            '0'
                        ],
                        [
                            "eid416",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${TG2}",
                            '0',
                            '0'
                        ],
                        [
                            "eid419",
                            "opacity",
                            5101,
                            96,
                            "linear",
                            "${TG2}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid366",
                            "left",
                            3500,
                            0,
                            "linear",
                            "${choose}",
                            '37px',
                            '37px'
                        ],
                        [
                            "eid430",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${aig2}",
                            '0',
                            '0'
                        ],
                        [
                            "eid433",
                            "opacity",
                            5302,
                            98,
                            "linear",
                            "${aig2}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid415",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${platinum2}",
                            '0',
                            '0'
                        ],
                        [
                            "eid386",
                            "opacity",
                            3793,
                            102,
                            "linear",
                            "${platinum2}",
                            '0',
                            '1'
                        ],
                        [
                            "eid410",
                            "opacity",
                            5000,
                            101,
                            "linear",
                            "${platinum2}",
                            '1',
                            '0'
                        ],
                        [
                            "eid315",
                            "left",
                            1495,
                            510,
                            "linear",
                            "${dreams}",
                            '35px',
                            '36px'
                        ],
                        [
                            "eid320",
                            "left",
                            3000,
                            500,
                            "linear",
                            "${dreams}",
                            '36px',
                            '38px'
                        ],
                        [
                            "eid423",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${TravelInsur}",
                            '0',
                            '0'
                        ],
                        [
                            "eid426",
                            "opacity",
                            5197,
                            105,
                            "linear",
                            "${TravelInsur}",
                            '0.000000',
                            '1'
                        ]
                    ]
                }
            },
            "Insure": {
                version: "6.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "6.0.0.400",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            type: 'image',
                            fill: ['rgba(0,0,0,0)', 'Insure.svg', '0px', '0px'],
                            r: null,
                            id: 'Insure',
                            t: 'image',
                            rect: ['-24px', '-10px', '132px', '27px', 'auto', 'auto'],
                            f: null
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            rect: [null, null, '83px', '17px']
                        }
                    }
                },
                timeline: {
                    duration: 0,
                    autoPlay: true,
                    data: [

                    ]
                }
            },
            "CallNow": {
                version: "6.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "6.0.0.400",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            rect: ['-19px', '-28px', '160px', '32px', 'auto', 'auto'],
                            filter: [0, 0, 1, 1, 0, 0, 0, 0, 'rgba(0,0,0,0)', 0, 0, 0],
                            id: 'compareButton',
                            type: 'image',
                            fill: ['rgba(0,0,0,0)', 'images/button_call_now.png', '0px', '0px']
                        },
                        {
                            rect: ['89px', '449px', '122px', '17px', 'auto', 'auto'],
                            id: 'Text',
                            text: '<p style=\"margin: 0px; font-family: Arial, Helvetica, sans-serif; font-weight: bold; font-style: italic; text-decoration: none; font-size: 13px; color: rgb(255, 255, 255); background-color: rgba(0, 0, 0, 0); letter-spacing: 0px; text-transform: none; word-spacing: 0px; text-align: center; text-indent: 0px; line-height: normal;\">Compare Plans</p>',
                            font: ['Arial, Helvetica, sans-serif', [24, ''], 'rgba(0,0,0,1)', 'normal', 'none', '', 'break-word', 'normal'],
                            type: 'text'
                        },
                        {
                            id: 'ComparePlans',
                            symbolName: 'ComparePlans',
                            rect: ['0px', '-46px', '122', '17', 'auto', 'auto'],
                            type: 'rect'
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            isStage: 'true',
                            rect: [undefined, undefined, '122px', '32px']
                        }
                    }
                },
                timeline: {
                    duration: 5821,
                    autoPlay: true,
                    data: [
                        [
                            "eid237",
                            "filter.saturate",
                            5281,
                            250,
                            "linear",
                            "${compareButton}",
                            '1',
                            '1.5'
                        ],
                        [
                            "eid238",
                            "filter.saturate",
                            5531,
                            245,
                            "linear",
                            "${compareButton}",
                            '1.5',
                            '1'
                        ],
                        [
                            "eid271",
                            "filter.saturate",
                            5821,
                            0,
                            "linear",
                            "${compareButton}",
                            '1',
                            '1'
                        ],
                        [
                            "eid6",
                            "top",
                            5281,
                            540,
                            "linear",
                            "${ComparePlans}",
                            '-17px',
                            '-46px'
                        ],
                        [
                            "eid5",
                            "left",
                            5281,
                            0,
                            "linear",
                            "${ComparePlans}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid262",
                            "width",
                            5281,
                            495,
                            "linear",
                            "${compareButton}",
                            '122px',
                            '160px'
                        ],
                        [
                            "eid263",
                            "width",
                            5776,
                            5,
                            "linear",
                            "${compareButton}",
                            '160px',
                            '122px'
                        ],
                        [
                            "eid273",
                            "width",
                            5781,
                            40,
                            "linear",
                            "${compareButton}",
                            '122px',
                            '160px'
                        ],
                        [
                            "eid260",
                            "height",
                            5281,
                            495,
                            "linear",
                            "${compareButton}",
                            '32px',
                            '42px'
                        ],
                        [
                            "eid261",
                            "height",
                            5776,
                            5,
                            "linear",
                            "${compareButton}",
                            '42px',
                            '32px'
                        ],
                        [
                            "eid274",
                            "height",
                            5781,
                            40,
                            "linear",
                            "${compareButton}",
                            '32px',
                            '42px'
                        ],
                        [
                            "eid247",
                            "left",
                            0,
                            0,
                            "linear",
                            "${compareButton}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid264",
                            "left",
                            5281,
                            495,
                            "linear",
                            "${compareButton}",
                            '0px',
                            '-21px'
                        ],
                        [
                            "eid265",
                            "left",
                            5776,
                            5,
                            "linear",
                            "${compareButton}",
                            '-21px',
                            '0px'
                        ],
                        [
                            "eid275",
                            "left",
                            5781,
                            40,
                            "linear",
                            "${compareButton}",
                            '0px',
                            '-19px'
                        ],
                        [
                            "eid249",
                            "top",
                            0,
                            0,
                            "linear",
                            "${compareButton}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid253",
                            "top",
                            5281,
                            500,
                            "linear",
                            "${compareButton}",
                            '0px',
                            '-28px'
                        ]
                    ]
                }
            },
            "ComparePlans": {
                version: "6.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "6.0.0.400",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            rect: ['0px', '0px', '122px', '17px', 'auto', 'auto'],
                            textStyle: ['', '', '', '', 'none'],
                            font: ['Arial, Helvetica, sans-serif', [24, 'px'], 'rgba(0,0,0,1)', '400', 'none', 'normal', 'break-word', 'normal'],
                            id: 'Text2',
                            text: '<p style=\"margin: 0px; font-family: Arial, Helvetica, sans-serif; font-weight: bold; font-style: italic; text-decoration: none; font-size: 13px; color: rgb(255, 255, 255); background-color: rgba(0, 0, 0, 0); letter-spacing: 0px; text-transform: none; word-spacing: 0px; text-align: center; text-indent: 0px; line-height: normal;\">Compare Plans</p>',
                            align: 'left',
                            type: 'text'
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            isStage: 'true',
                            rect: [undefined, undefined, '122px', '17px']
                        }
                    }
                },
                timeline: {
                    duration: 0,
                    autoPlay: true,
                    data: [

                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("AllPlans_300x600_CN_edgeActions.js");
})("EDGE-74136739");
